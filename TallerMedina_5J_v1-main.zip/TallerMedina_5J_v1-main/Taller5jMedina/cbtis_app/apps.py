from django.apps import AppConfig


class CbtisAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cbtis_app'
