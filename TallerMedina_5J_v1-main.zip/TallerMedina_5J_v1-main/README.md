# TallerMedina_5J_v1
Taller v1 Nicolas Medina
